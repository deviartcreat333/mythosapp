router.post('/media/index', async (req, res) => {
  await saveEmbeddingToDB(req.body);
  res.sendStatus(200);
});

router.post('/media/search', async (req, res) => {
  const results = await findSimilarEmbeddings(req.body.query);
  res.json({ results });
});