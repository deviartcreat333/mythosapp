# AI Voice Plugin System

A modular plugin system for AI-native voice rooms, chat agents, and multimodal collaboration.
